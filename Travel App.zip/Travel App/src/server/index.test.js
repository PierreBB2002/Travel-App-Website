const request = require("supertest");
const app = require("./index");

describe("GET /trips", () => {
  it("should return an empty array", async () => {
    const res = await request(app).get("/trips");
    expect(res.statusCode).toEqual(200);
    expect(res.body).toEqual([]);
  });
});
