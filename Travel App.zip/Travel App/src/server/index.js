const dotenv = require('dotenv');
dotenv.config();

const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

 // Create an Express app
const app = express();

// Middleware configuration
app.use(express.json());
app.use(cors());
app.use(bodyParser.json());
app.use(express.static('dist'));

let trips = [];

// Retrieve all trips
app.get('/trips', (req, res) => {
  // JSON data
  res.json(trips); 
});

// Add a new trip
app.post('/trips', (req, res) => {
  const trip = req.body; // Get the trip from the request body
  trips.push(trip); // Store the trip in array
  res.status(201).json(trip); // Send a 201 status to notify the user that the trip is added
});

// Only start the server if and only if this file is run directly
if (require.main === module) {
  const port = process.env.PORT || 3000;
  app.listen(port, () => {
    log.info(`Server listening on port ${port}`);
  });
}

// Exporting the app for testing
module.exports = app;
