// Pierre Backleh

//import all required files
import "./styles/style.scss";
import "./styles/header.scss";
import "./styles/tripInfo.scss";
import "./styles/tripForm.scss";
import "./styles/tripList.scss";


// import the js files
import "./js/app.js";
