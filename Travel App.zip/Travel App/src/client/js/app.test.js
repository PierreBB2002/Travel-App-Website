import { daysLeft } from "./daysLeft.js";

test("daysLeft should calculate correct days difference", () => {
  const futureDate = new Date();
  futureDate.setDate(futureDate.getDate() + 10); // 10 days in the future
  const result = daysLeft(futureDate.toISOString().split("T")[0]);
  expect(result).toBe(10);
});
