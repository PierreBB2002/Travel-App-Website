document.addEventListener("DOMContentLoaded", function () {
  
  // getting the new trip form
  const newTripForm = document.getElementById("new-trip-form");

  const ListOfTrip = document.getElementById("trip-list");
  const CityLocation = document.getElementById("location-info");
  const weatherCityInfo = document.getElementById("weather-info"); 

  // API Key for geonames
  const geonamesAPIKey = 'pierreBB';

  //API key for weatherbit
  const weatherbitAPIKey = 'e6eaf95a2f9246308510ad7633c61471'; 

  //API key for pixabay
  const pixabayAPIKey = '45761965-465d264df394204e79f79f32c';

  // URL for weatherbit API
  const weatherbitURL = 'https://api.weatherbit.io/v2.0/forecast/daily';

  if ('serviceWorker' in navigator) {
    window.addEventListener('load', function () {
      navigator.serviceWorker.register('/service-worker.js')
        .then(function (registration) {
          console.log('Service Worker registered with scope:', registration.scope);
        }, function (error) {
          console.log('Service Worker registration failed:', error);
        });
    });
  }

  self.addEventListener('fetch', (event) => {
    const requestUrl = new URL(event.request.url);
    
    // Example: Only cache Geonames, Weatherbit, or Pixabay API requests
    if (requestUrl.origin === 'https://api.geonames.org' || requestUrl.origin === 'https://api.weatherbit.io' || requestUrl.origin === 'https://pixabay.com') {
      event.respondWith(
        caches.open(CACHE_NAME).then((cache) => {
          return cache.match(event.request).then((response) => {
            return response || fetch(event.request).then((networkResponse) => {
              cache.put(event.request, networkResponse.clone());
              return networkResponse;
            });
          });
        })
      );
    }
  });
  

  // Event to submit the entered data and save it
  newTripForm.addEventListener("submit", function (e) {
    e.preventDefault();

    const Entered_Location = document.getElementById("location").value;
    const departDateEntered = document.getElementById("departure-date").value;

    // Getting location data from Geonames API
    fetchLocationData(Entered_Location)
      .then((locationData) => {
        // Create a new trip city with all the location details and store it
        const newTrip = {
          location: locationData.name,
          departureDate: departDateEntered,
          //latitude and longitude are used to determine the predictied weather
          latitude: locationData.lat,
          longitude: locationData.lng,
          country: locationData.countryName,
        };

        // Getting weather data for the trip
        TakingWeatherData({ latitude: locationData.lat, longitude: locationData.lng }, departDateEntered)
          .then((weatherData) => {
            // submit the new trip in the trip list
            submitTrip(newTrip, weatherData); 

            // Clear the form fields and restart it
            newTripForm.reset();

            // Hide the form
            newTripForm.classList.add("hidden");

            displayCityLocation(locationData);
            displayweatherCityInfo(weatherData);
          })
          .catch((error) => {
            console.error("Error fetching weather data:", error);
            alert("Error fetching weather data. Please try again with another city!");
          });
      })
      .catch((error) => {
        console.error("Error fetching location data:", error);
        alert("Error finding location. Please try again with another city.");
      });
  });

  // Function to get location data from Geonames API
  async function fetchLocationData(location) {
    const url_geonames = `http://api.geonames.org/searchJSON?q=${location}&maxRows=1&username=${geonamesAPIKey}`;

    try {
      const response = await fetch(url_geonames);
      const data = await response.json();

      if (data.geonames && data.geonames.length > 0) {
        return {
          name: data.geonames[0].name,
          lat: data.geonames[0].lat,
          lng: data.geonames[0].lng,
          countryName: data.geonames[0].countryName,
        };
      } else {
        throw new Error("Location not found!");
      }
    } catch (error) {
      throw error;
    }
  }

  // Function to submit a trip card in the trip list
  function submitTrip(trip, weatherData) {
    // Create a trip card element
    const tripCard = document.createElement("div");
    const tripItem = document.createElement("li");
    tripCard.classList.add("trip-card");

    // Set the city image
    const city_image = document.createElement("img");

    GetCityImage(trip.location)
      .then(imageUrl => {
        city_image.src = imageUrl;
      })
      .catch(error => {
        console.error("Error fetching the image:", error);
        city_image.src = "https://via.placeholder.com/400x200";
      });
    city_image.alt = `Image of ${trip.location}`;
    tripCard.appendChild(city_image);

    const tripInfo = document.createElement("div");
    tripInfo.classList.add("trip-info");

    // Trip destination city and append it to the card
    const tripCityDestination = document.createElement("h2");
    tripCityDestination.textContent = `My trip to: ${trip.location}`;
    tripInfo.appendChild(tripCityDestination);

    // Trip departure date
    const depDate = document.createElement("p");
    depDate.textContent = `Departing: ${trip.departureDate}`;
    tripInfo.appendChild(depDate);

    // display the country
    const country = document.createElement("p");
    country.textContent = `Country: ${trip.country}`;
    tripInfo.appendChild(country);

    // display the latitude 
    const latitude_city = document.createElement("p");
    latitude_city.classList.add("countdown");
    latitude_city.textContent = `Latitude: ${trip.latitude}`;
    tripInfo.appendChild(latitude_city);

    // display the longitude longitude
    const longitude_city = document.createElement("p");
    longitude_city.classList.add("countdown");
    longitude_city.textContent = `longitude: ${trip.longitude}`;
    tripInfo.appendChild(longitude_city);

    // display the countdown
    const tripCountdownTimer = document.createElement("p");
    tripCountdownTimer.textContent = `Countdown: ${calculateCountdown(trip.departureDate)} days`;
    tripInfo.appendChild(tripCountdownTimer);

    // Weather Information (Add to tripInfo)
    const tripWeather = document.createElement("p");
    tripWeather.textContent = `Weather: Temperature: ${weatherData.data[0].temp} degrees, Description: ${weatherData.data[0].weather.description}`;
    tripInfo.appendChild(tripWeather);

    // Save button
    const addRemoveButtons = document.createElement("div");
    addRemoveButtons.classList.add("buttons");

    const saveButton = document.createElement("button");
    saveButton.classList.add("save-button");
    saveButton.textContent = "Save Trip";
    addRemoveButtons.appendChild(saveButton);

    //Delete button 
    const removeButton = document.createElement("button");
    removeButton.classList.add("remove-button");
    removeButton.textContent = "Delete Trip";
    addRemoveButtons.appendChild(removeButton);

    tripInfo.appendChild(addRemoveButtons);

    // Event to remove and delete the trip from the local storage
    removeButton.addEventListener("click", () => {
      ListOfTrip.removeChild(tripCard);
      deleteTripFromLocalStorage(trip, tripItem);
    });

    // Event to save and store the trip in the local storage
    saveButton.addEventListener("click", () => {
      saveTrip(trip);
      saveButton.disabled = true;
      saveButton.textContent = "Trip Saved";
    });

    function deleteTripFromLocalStorage(trip, tripItem) {
      // getting the existing trips from localStorage
      let listOfTrips = JSON.parse(localStorage.getItem("trips")) || [];
    
      // Filtering the desired trip to be removed
      listOfTrips = listOfTrips.filter(savedTrip => 
        savedTrip.location !== trip.location || 
        savedTrip.departureDate !== trip.departureDate
      );
    
      // Save the updated list back to the localStorage
      localStorage.setItem("trips", JSON.stringify(listOfTrips));
    
      // Remove the trip item from the UI
      tripItem.remove();
    
      console.log("Trip removed from the local storage successfully!:", trip);
    }

    // Append trip info to trip card
    tripCard.appendChild(tripInfo);

    // Append trip card to trip list
    ListOfTrip.appendChild(tripCard);
  }

  // Function to save trip on the local storage
  function saveTrip(trip) {
    let listOfTrips = JSON.parse(localStorage.getItem("trips")) || [];
    listOfTrips.push(trip);
    localStorage.setItem("trips", JSON.stringify(listOfTrips));
    console.log("Trip saved and uploaded to the local storage:", trip);
  }

  // Function to display location information in the trip card
  function displayCityLocation(locationData) {
    CityLocation.innerHTML = `
        <p><strong>Location:</strong> ${locationData.name}</p>
        <p><strong>Latitude:</strong> ${locationData.lat}</p>
        <p><strong>Longitude:</strong> ${locationData.lng}</p>
        <p><strong>Country:</strong> ${locationData.countryName}</p>
      `;
  }

  // Function to calculate the days left until the departure date
  function calculateCountdown(departureDate) {
    const currDate = new Date();
    const depDate = new Date(departureDate);
    const diffTime = depDate - currDate;
    // converte the difference from date to days
    const numOfDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return numOfDays;
  }

  // Function to display the weather information 
  function displayweatherCityInfo(weatherData) {
    weatherCityInfo.innerHTML = `
      <p><strong>Temperature:</strong> ${weatherData.data[0].temp} degrees</p>
      <p><strong>Description:</strong> ${weatherData.data[0].weather.description}</p>
    `;
  }

  // Function to get all weather data from Weatherbit API
  async function TakingWeatherData(coordinates, departureDate) {
    // to get the date as the format [year-month-day]
    const formattedDepartureDate = new Date(departureDate).toISOString().slice(0, 10); 
    const weather_url = `${weatherbitURL}?lat=${coordinates.latitude}&lon=${coordinates.longitude}&key=${weatherbitAPIKey}&days=16&start_date=${formattedDepartureDate}`; 

    try {
      const response = await fetch(weather_url);
      const data = await response.json();
      return data;
    } catch (error) {
      console.error("Error while fetching the weather data:", error);
      throw error;
    }
  }

  async function GetCityImage(location) {
    const encodedLocation = encodeURIComponent(location); // URL encode the location
    const url = `https://pixabay.com/api/?key=${pixabayAPIKey}&q=${encodedLocation}&image_type=photo`; // Base URL
  
    try {
      const response = await fetch(url);
      const data = await response.json();
  
      if (data.hits.length > 0) {
        // Return the URL of the first image of the city
        return data.hits[0].webformatURL; 
      } else {
        console.error("No images found for:", location);
        // Return a placeholder default image URL
        return "https://via.placeholder.com/400x200";
      }
    } catch (error) {
      console.error("Error fetching the image of the city:", error);
      throw error;
    }
  }

  // Load all the saved trips
  const listOfTrips = JSON.parse(localStorage.getItem("trips")) || [];
  listOfTrips.forEach((trip) => {
    TakingWeatherData({ latitude: trip.latitude, longitude: trip.longitude }, trip.departureDate)
      .then(weatherData => submitTrip(trip, weatherData))
      .catch(error => console.error("Error taking weather data for the saved trip:", error));
  });
});